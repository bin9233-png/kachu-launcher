# Kachu Launcher - GitHub Actions Windows Build Pack

## What this is
This pack adds a GitHub Actions workflow that builds your Tauri launcher on **Windows** and uploads the EXE/MSI as an **Artifact**.

## How to use
1) In your repo root, you must have:
- `ui/`
- `src-tauri/`

2) Copy the `.github/` folder from this pack into your repo root.

Your repo should look like:
- `.github/workflows/build-windows.yml`
- `ui/`
- `src-tauri/`

3) Commit & push.

4) On GitHub:
Actions → **Build Windows (Kachu Launcher)** → **Run workflow**

5) Download the Artifact:
**KachuLauncher-Windows**

## Where the EXE/MSI is (inside the artifact)
- `src-tauri/target/release/bundle/nsis/*.exe`
- `src-tauri/target/release/bundle/msi/*.msi`
- sometimes `src-tauri/target/release/*.exe`

## Common fix
If you get an icon error, make sure this exists in your repo:
`src-tauri/icons/icon.ico`
